module.exports = new Set(['__proto__', 'constructor', 'prototype']);
